ls = ["ls", "more", "jkwjd", "cipher"]
cc = "more"
if cc == any(list(ls)):
    print("yes")
