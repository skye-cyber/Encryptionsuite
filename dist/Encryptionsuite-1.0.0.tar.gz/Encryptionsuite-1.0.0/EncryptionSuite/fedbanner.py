banner = '''\033[1;94m
ffffffffffff     eeeeeeeeeee    DDDDD&&8_
ffffffffffff     EEEEEEEEEEE    DDD DDD-D8
fff              EE             DDD      DD
\033[1;94mfff              EE             DDD       DD   \033[1;96;5m   88888     \033[0m
\033[1;93mfff              EEEEEEEEEEE    DDD        DD   \033[1;96;5m  8888 8888888888888  \033[0m
\033[1;93mffffffffffff     EEEEEEEEEEE    DDD        DD   \033[1;93;5m  8  O  8888888888>  \033[0m
\033[1;93mffffffffffff     EE             DDD        DD   \033[1;96;5m  8888 8888888888888\033[0m
\033[1;94mfff              EE             DDD        DD   \033[1;96;5m  88888   \033[0m \033[1;94m
fff              EE             DDD       DD
fff              EEEEEEEEEEE    DDDDDDD D D
fff              EEEEEEEEEEE    DDDDD DD /
\033[0m'''


print(banner)
